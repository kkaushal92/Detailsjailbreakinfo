//
//  JailbreakDetector.swift
//  JailBreakcheck
//
//  Created by Karan Kaushal on 3/12/25.
//


import Foundation
import Darwin
import MachO

/// JailbreakDetector
/// A compact, heavily-logged jailbreak / tweak-injection detector.
/// - Target: iOS 16+. Uses public APIs only (FileManager, dyld, sysctl).
/// - Returns a verbose log and a structured JSON report for sharing.
/// NOTE: This is for defensive detection & analysis only.
public final class JailbreakDetector {
    public static let shared = JailbreakDetector()
    private init() {}
    
    /// Holds chronological logs of checks
    private var logs: [String] = []
    private let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        return f
    }()
    
    // MARK: - Public API
    
    /// Run all detection checks. Results are appended to `logs`.
    /// - Returns: a dictionary of boolean findings (shallow summary).
    public func runAllChecks() -> [String: Bool] {
        logs.removeAll()
        log("=== JailbreakDetector started ===")
        
        var findings: [String: Bool] = [:]
        
        // File & artifact checks
        findings["foundKnownJailbreakFiles"] = checkKnownJailbreakFiles()
        findings["foundRootlessPaths"] = checkRootlessPaths()
        findings["foundPackageManager"] = checkPackageManagerFiles()
        
        // Sandbox / write test
        findings["canWriteOutsideSandbox"] = canWriteOutsideSandbox()
        
        // Environment / dyld checks
        findings["foundDYLD_INSERT_LIBRARIES"] = checkDYLDEnv()
        findings["foundSuspiciousDylibs"] = checkLoadedImageNames()
        
        // Executables & binaries
        findings["foundSuOrBash"] = checkCommonBinaries()
        
        // Runtime tampering heuristics
        findings["foundTweakInjectionIndicators"] = findings["foundSuspiciousDylibs"] ?? false || findings["foundDYLD_INSERT_LIBRARIES"] ?? false
        
        // Kernel / low-level heuristics (best-effort)
        findings["kernOsreleaseMismatch"] = checkKernelVersionAnomaly()
        
        log("=== JailbreakDetector finished ===")
        return findings
    }
    
    /// Returns the verbose logs as a single string.
    public func logsText() -> String {
        return logs.joined(separator: "\n")
    }
    
    /// Returns a JSON string report with findings and logs (UTF-8 safe).
    /// Useful to paste into messages or attach to bug reports.
    public func generateReportJSON() -> String {
        let summary = runAllChecks()
        let payload: [String: Any] = [
            "timestamp": dateFormatter.string(from: Date()),
            "summary": summary,
            "logs": logs
        ]
        if let data = try? JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted]),
           let json = String(data: data, encoding: .utf8) {
            return json
        } else {
            log("Failed to create JSON report")
            return "{\"error\":\"failed to serialize report\"}"
        }
    }
    
    // MARK: - Low level check implementations
    
    /// Check common jailbreak files/paths (Cydia, apt, etc.)
    private func checkKnownJailbreakFiles() -> Bool {
        let candidates = [
            "/Applications/Cydia.app",
            "/Applications/Sileo.app",
            "/usr/sbin/sshd",
            "/bin/bash",
            "/etc/apt",
            "/private/var/lib/apt",
            "/private/var/lib/dpkg",
            "/private/var/tmp/cydia.log",
            "/var/jb" // rootless locations sometimes
        ]
        var foundAny = false
        for p in candidates {
            let exists = FileManager.default.fileExists(atPath: p)
            log("checkKnownJailbreakFiles: \(p) -> \(exists)")
            if exists { foundAny = true }
        }
        return foundAny
    }
    
    /// Check for common rootless / dopaminelike placement such as /var/jb and other indicators.
    private func checkRootlessPaths() -> Bool {
        let candidates = [
            "/var/jb",
            "/private/var/jb",
            "/var/lib/dpkg",
            "/private/var/lib/cydia",
            "/var/mobile/Library/TweakInjectors"
        ]
        var foundAny = false
        for p in candidates {
            let exists = FileManager.default.fileExists(atPath: p)
            log("checkRootlessPaths: \(p) -> \(exists)")
            if exists { foundAny = true }
        }
        return foundAny
    }
    
    /// Check for package manager artifacts
    private func checkPackageManagerFiles() -> Bool {
        let candidates = ["/usr/bin/dpkg", "/usr/bin/apt-get", "/usr/sbin/apt"]
        var foundAny = false
        for p in candidates {
            let exists = FileManager.default.fileExists(atPath: p)
            log("checkPackageManagerFiles: \(p) -> \(exists)")
            if exists { foundAny = true }
        }
        return foundAny
    }
    
    /// Try to write outside the sandbox (e.g., /private). If succeeds, sandbox escape/root present.
    /// This writes then removes a file under /private and returns true if write succeeded.
    private func canWriteOutsideSandbox() -> Bool {
        let testPath = "/private/jb_test_\(UUID().uuidString).tmp"
        let content = "jb-test".data(using: .utf8)!
        do {
            try content.write(to: URL(fileURLWithPath: testPath), options: .atomic)
            log("canWriteOutsideSandbox: successfully wrote to \(testPath) — removing")
            try FileManager.default.removeItem(atPath: testPath)
            return true
        } catch {
            log("canWriteOutsideSandbox: write failed (\(error.localizedDescription))")
            return false
        }
    }
    
    /// Detect common binaries: su, bash, sudo etc.
    private func checkCommonBinaries() -> Bool {
        let candidates = ["/bin/sh", "/bin/bash", "/usr/sbin/sshd", "/sbin/su", "/usr/bin/sudo", "/usr/local/bin/ssh"]
        var foundAny = false
        for p in candidates {
            let exists = FileManager.default.fileExists(atPath: p)
            log("checkCommonBinaries: \(p) -> \(exists)")
            if exists { foundAny = true }
        }
        return foundAny
    }
    
    /// Inspect dyld environment variables that injection frameworks list (DYLD_INSERT_LIBRARIES, etc.)
    private func checkDYLDEnv() -> Bool {
        if let value = getenv("DYLD_INSERT_LIBRARIES") {
            let s = String(cString: value)
            log("checkDYLDEnv: DYLD_INSERT_LIBRARIES present => \(s)")
            return true
        } else {
            log("checkDYLDEnv: DYLD_INSERT_LIBRARIES not present")
            return false
        }
    }
    
    /// Enumerate currently loaded image names in this process and look for suspicious names (ElleKit, Substrate, Substitute, CydiaSubstrate, etc.)
    private func checkLoadedImageNames() -> Bool {
        var suspiciousFound = false
        let suspiciousNames = [
            "ElleKit",
            "CydiaSubstrate",
            "Substrate",
            "Substitute",
            "MobileSubstrate",
            "libsubstrate",
            "tweakinjector",
            "dopl" /* partial to detect dopamine-related strings */,
            "routhide",
            "roothide",
            "frida"
        ]
        let imageCount = _dyld_image_count()
        log("checkLoadedImageNames: _dyld_image_count = \(imageCount)")
        for i in 0..<imageCount {
            if let cname = _dyld_get_image_name(i) {
                let name = String(cString: cname)
                log("dyld image \(i): \(name)")
                for s in suspiciousNames {
                    if name.localizedCaseInsensitiveContains(s) {
                        log("dyld: suspicious substring '\(s)' matched in image \(name)")
                        suspiciousFound = true
                    }
                }
            }
        }
        return suspiciousFound
    }
    
    /// Best-effort anomaly check against kernel osrelease (non-definitive).
    /// Idea: if kern.osrelease can't be read or is unusual vs. userland, log it.
    private func checkKernelVersionAnomaly() -> Bool {
        var size = 0
        if sysctlbyname("kern.osrelease", nil, &size, nil, 0) != 0 {
            log("checkKernelVersionAnomaly: sysctlbyname kern.osrelease failed")
            return true // suspicious if we can't get it
        }
        var buf = [CChar](repeating: 0, count: size)
        if sysctlbyname("kern.osrelease", &buf, &size, nil, 0) != 0 {
            log("checkKernelVersionAnomaly: sysctlbyname kern.osrelease read failed")
            return true
        }
        let kernVer = String(cString: buf)
        log("checkKernelVersionAnomaly: kern.osrelease = \(kernVer)")
        // crude heuristic: if contains "test" or "debug" or unusually short/empty -> suspicious
        if kernVer.lowercased().contains("debug") || kernVer.lowercased().contains("test") || kernVer.count < 3 {
            log("checkKernelVersionAnomaly: kernel string suspicious -> \(kernVer)")
            return true
        }
        return false
    }
    
    // MARK: - Logging helpers
    
    private func log(_ s: String) {
        let ts = dateFormatter.string(from: Date())
        let line = "[\(ts)] \(s)"
        logs.append(line)
        // Always print to console in debug builds; for release you can toggle
        print(line)
    }
}
