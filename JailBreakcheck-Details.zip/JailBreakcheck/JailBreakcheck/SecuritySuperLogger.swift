//
//  SecuritySuperLogger.swift
//  JailBreakCheck
//
//  Created by Karan Kaushal on 3/12/25.
//

import Foundation
import UIKit
import MachO
import Darwin

final class SecuritySuperLogger {

    static let shared = SecuritySuperLogger()
    private init() {}

    // MARK: - Public scan methods for each type

    func collectFilesystemLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        let paths = ["/", "/Applications", "/var", "/usr", "/etc", "/bin", "/sbin",
                     "/private", "/var/jb", "/Library/MobileSubstrate",
                     "/var/mobile", "/var/root"]
        
        for path in paths {
            let exists = FileManager.default.fileExists(atPath: path)
            var contents: [String] = []
            if exists, let files = try? FileManager.default.contentsOfDirectory(atPath: path) {
                contents = files
            }
            result[path] = ["exists": exists, "contents": contents]
        }
        
        // Test write access outside sandbox
        let testPath = "/private/test_write_\(UUID().uuidString)"
        var writable = false
        do {
            try "test".write(toFile: testPath, atomically: true, encoding: .utf8)
            writable = true
            try FileManager.default.removeItem(atPath: testPath)
        } catch { writable = false }
        result["writable_outside_sandbox"] = writable
        
        return result
    }

    func collectDylibsLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        let count = _dyld_image_count()
        for i in 0..<count {
            if let name = _dyld_get_image_name(i) {
                result["image_\(i)"] = String(cString: name)
            }
        }
        return result
    }

    func collectMachPortsLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        result["note"] = "mach_port_space_info cannot be safely called in Swift/iOS sandbox"
        return result
    }

    func collectSysctlLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        let keys = ["hw.ncpu", "hw.machine", "kern.osversion", "kern.hostname", "kern.boottime", "security.mac.proc_enforce"]
        for key in keys {
            var size = 0
            sysctlbyname(key, nil, &size, nil, 0)
            var value = [CChar](repeating: 0, count: size)
            sysctlbyname(key, &value, &size, nil, 0)
            result[key] = String(cString: value)
        }
        return result
    }

    func collectSandboxLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        let deniedPaths = ["/root", "/etc/apt", "/var/mobile/Library/Caches", "/private/var/root"]
        for path in deniedPaths {
            result[path] = FileManager.default.isReadableFile(atPath: path)
        }
        return result
    }

    func collectEntitlementsLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        if let dict = Bundle.main.infoDictionary {
            dict.forEach { key, value in
                result[key] = value
            }
        }
        return result
    }

    func collectMemoryMapLogs() -> [String: Any] {
#if targetEnvironment(simulator)
        return ["note": "Memory scan not available on Simulator"]
#else
        var result: [String: Any] = [:]
        let task = mach_task_self_
        var address: vm_address_t = 0

        while true {
            var size: vm_size_t = 0
            var info = vm_region_basic_info_data_t()
            var infoCount = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<natural_t>.size)
            var objectName: mach_port_t = 0

            let kr = withUnsafeMutablePointer(to: &info) { infoPtr -> kern_return_t in
                infoPtr.withMemoryRebound(to: integer_t.self, capacity: Int(infoCount)) { intPtr in
                    var addr = address
                    var sz = size
                    return vm_region(
                        task,
                        &addr,
                        &sz,
                        VM_REGION_BASIC_INFO,
                        intPtr,
                        &infoCount,
                        &objectName
                    )
                }
            }

            if kr != KERN_SUCCESS { break }

            result["\(address)"] = size
            address += size
        }
        return result
#endif
    }

    func collectHookLogs() -> [String: Any] {
        let functions = ["open", "stat", "lstat", "fork", "execve", "ptrace", "sysctl", "getuid", "setuid"]
        var result: [String: Any] = [:]
        for fn in functions {
            if let sym = dlsym(UnsafeMutableRawPointer(bitPattern: -2), fn) {
                result[fn] = "\(sym)"
            }
        }
        return result
    }

    func collectMountsLogs() -> [String: Any] {
        var result: [String: Any] = [:]
        var mountsPointer: UnsafeMutablePointer<statfs>? = nil
        let count = Int(getmntinfo(&mountsPointer, 0))
        
        if let mounts = mountsPointer {
            for i in 0..<count {
                let m = mounts[i]
                let mountPoint = withUnsafePointer(to: m.f_mntonname) {
                    $0.withMemoryRebound(to: CChar.self, capacity: MemoryLayout.size(ofValue: m.f_mntonname)) {
                        String(cString: $0)
                    }
                }
                let fsType = withUnsafePointer(to: m.f_fstypename) {
                    $0.withMemoryRebound(to: CChar.self, capacity: MemoryLayout.size(ofValue: m.f_fstypename)) {
                        String(cString: $0)
                    }
                }
                result[mountPoint] = fsType
            }
        }
        
        return result
    }

}
