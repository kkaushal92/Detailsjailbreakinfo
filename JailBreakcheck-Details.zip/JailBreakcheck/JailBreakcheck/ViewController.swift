//
//  ViewController.swift
//  JailBreakcheck
//
//  Created by Karan Kaushal on 3/12/25.
//

import UIKit
import MachO    // Needed for dyld functions

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        setupButtons()
    }
    
    // MARK: - UI Setup
    
    private func setupButtons() {
        let logs = [
            ("Filesystem Logs", #selector(exportFilesystem)),
            ("Dylibs Logs", #selector(exportDylibs)),
            ("Mach Ports Logs", #selector(exportMachPorts)),
            ("Sysctl Logs", #selector(exportSysctl)),
            ("Sandbox Logs", #selector(exportSandbox)),
            ("Entitlements Logs", #selector(exportEntitlements)),
            ("Memory Map Logs", #selector(exportMemoryMap)),
            ("Hooks Logs", #selector(exportHookedFunctions)),
            ("Mounts Logs", #selector(exportMounts))
        ]
        
        var previousButton: UIButton? = nil
        
        for (title, selector) in logs {
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
            button.addTarget(self, action: selector, for: .touchUpInside)
            button.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(button)
            
            NSLayoutConstraint.activate([
                button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                button.heightAnchor.constraint(equalToConstant: 44),
                button.widthAnchor.constraint(equalToConstant: 250)
            ])
            
            if let prev = previousButton {
                button.topAnchor.constraint(equalTo: prev.bottomAnchor, constant: 12).isActive = true
            } else {
                button.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20).isActive = true
            }
            
            previousButton = button
        }
    }

    // MARK: - Individual Button Actions

    @objc func exportDylibs() {
        let data = SecuritySuperLogger.shared.collectDylibsLogs()
        saveJSONReport(filename: "dylibs.json", data: data)
    }

    @objc func exportMachPorts() {
        let data = SecuritySuperLogger.shared.collectMachPortsLogs()
        saveJSONReport(filename: "mach_ports.json", data: data)
    }

    @objc func exportSysctl() {
        let data = SecuritySuperLogger.shared.collectSysctlLogs()
        saveJSONReport(filename: "sysctl.json", data: data)
    }

    @objc func exportSandbox() {
        let data = SecuritySuperLogger.shared.collectSandboxLogs()
        saveJSONReport(filename: "sandbox.json", data: data)
    }

    @objc func exportEntitlements() {
        let data = SecuritySuperLogger.shared.collectEntitlementsLogs()
        saveJSONReport(filename: "entitlements.json", data: data)
    }

    @objc func exportMemoryMap() {
        let data = SecuritySuperLogger.shared.collectMemoryMapLogs()
        saveJSONReport(filename: "memory_map.json", data: data)
    }

    @objc func exportHookedFunctions() {
        let data = SecuritySuperLogger.shared.collectHookLogs()
        saveJSONReport(filename: "hooked_functions.json", data: data)
    }

    @objc func exportMounts() {
        let data = SecuritySuperLogger.shared.collectMountsLogs()
        saveJSONReport(filename: "mounts.json", data: data)
    }

    @objc func exportFilesystem() {
        let data = SecuritySuperLogger.shared.collectFilesystemLogs()
        saveJSONReport(filename: "filesystem.json", data: data)
    }

    // Repeat similarly for other logs...

    // MARK: - Helper

    private func saveJSONReport(filename: String, data: [String: Any]) {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documents.appendingPathComponent(filename)
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: data, options: [.prettyPrinted])
            try jsonData.write(to: fileURL)
            print("✅ Saved JSON at:", fileURL.path)
            
            // Optional: share immediately
            let activityVC = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
            activityVC.popoverPresentationController?.sourceView = self.view
            present(activityVC, animated: true)
            
        } catch {
            print("❌ Failed to save JSON:", error)
        }
    }

   

}


