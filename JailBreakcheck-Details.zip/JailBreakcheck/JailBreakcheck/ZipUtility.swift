import UIKit
import Foundation



extension OutputStream {
    func write(data: Data) {
        data.withUnsafeBytes { ptr in
            guard let addr = ptr.baseAddress?.assumingMemoryBound(to: UInt8.self) else { return }
            var bytesRemaining = data.count
            var totalWritten = 0
            while bytesRemaining > 0 {
                let written = self.write(addr.advanced(by: totalWritten), maxLength: bytesRemaining)
                if written < 0 { break } // error
                bytesRemaining -= written
                totalWritten += written
            }
        }
    }
}
